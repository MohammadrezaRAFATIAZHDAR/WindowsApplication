﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinnessEntity;
using System.Data.Entity;

namespace DataAccessLayer
{
    public class DALLogincs
    {
        DataBace db = new DataBace();

        public byte Login(string username,string password)
        {
            if (db.Users.Count() == 0)
            {
                return 0;
                //it means nth hasn't been saved in our database
            }
            else
            {
                if (db.Users.Any(i => i.password == password && i.username == username))
                {
                    return 1;
                }
                else
                {
                    return 2;
                }

                
               
            }
        }

        public void Register(login adm)
        {
            db.Users.Add(adm);
            db.SaveChanges();
        }
    }
}
