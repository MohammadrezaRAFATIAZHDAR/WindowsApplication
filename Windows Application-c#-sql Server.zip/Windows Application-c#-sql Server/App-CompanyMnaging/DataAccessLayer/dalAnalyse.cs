﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinnessEntity;
using System.Data.Entity;


namespace DataAccessLayer
{
    public class dalAnalyse
    {
        DataBace db = new DataBace();
        
        public string Create(YearIncome income)
        {
            db.YearIncomes.Add(income);
            db.SaveChanges();
            return "successfully Added";

        }
        //for the chart to analyse a year
        public List<double> Read()
        {
            return (from i in db.YearIncomes select i.Income).ToList();
        }
    }
}
