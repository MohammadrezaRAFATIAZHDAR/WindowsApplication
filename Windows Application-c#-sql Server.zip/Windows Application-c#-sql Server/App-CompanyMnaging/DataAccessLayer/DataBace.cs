﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinnessEntity;
using System.Data.Entity;

namespace DataAccessLayer
{
    public class DataBace : DbContext
    {
        public DataBace() : base("name=IT_Company") { }
        public DbSet<Employee> employees { get; set; }
        public DbSet<contract> contracts { get; set; }
        public DbSet<Clientes> clientes { get; set; }
        public DbSet<YearIncome> YearIncomes { get; set; }
        public DbSet<login> Users { get; set; }
        
    }
}
