﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinnessEntity;
using BussinessLogicLayer;

namespace managing_tecknology_company_application.formes
{
    public partial class ClientesForm : Form
    {
        public ClientesForm()
        {
            InitializeComponent();
        }

        BLLclientes bllclient = new BLLclientes();

        //Specify the progress of the project 
        bool flag = true;

        int id;

        //datagridview
        void DGV()
        {
            guna2DataGridView1.DataSource = null;
            guna2DataGridView1.DataSource = bllclient.Read();
            guna2DataGridView1.Columns["id"].Visible = false;
        }

        void Clear()
        {

            foreach (var item in Controls)
            {
                if (item.GetType().ToString() == "Guna.UI2.WinForms.Guna2TextBox")
                {
                    (item as TextBox).Text = "";
                }
            }
        }

        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {
            guna2DataGridView1.DataSource = null;
            guna2DataGridView1.DataSource = bllclient.Read(guna2TextBox1.Text);
        }

        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {

            Clientes clnt = new Clientes();
            clnt.Name = guna2TextBox5_name.Text;
            clnt.Phone = guna2TextBox2_phone.Text;
            clnt.Address = guna2TextBox3_address.Text;
            clnt.EmailAddress = guna2TextBox4_adresmail.Text;
            clnt.subscription_number = guna2TextBox6_idmmember.Text;
            clnt.DateofMembership = guna2DateTimePicker1.Value.Date;
            clnt.Type = checkedListBox1_type.SelectedItem.ToString();

            if (flag)
            {
                //create
                MessageBox.Show(bllclient.Create(clnt));
            }
            else if (!flag)
            {
                //update
                MessageBox.Show(bllclient.Update(id, clnt));
                flag = true;
                guna2GradientButton1.Text = "Save";
            }
            DGV();
            Clear();

        }

        private void guna2DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            id = Convert.ToInt32(guna2DataGridView1.Rows[guna2DataGridView1.CurrentRow.Index].Cells["id"].Value);
        }

        private void guna2DataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.ColumnIndex != -1 && e.RowIndex != -1 && e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                contextMenuStrip1.Show(Cursor.Position.X, Cursor.Position.Y);
            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clientes clnt = bllclient.Read(id);
            guna2TextBox5_name.Text = clnt.Name;
            guna2TextBox2_phone.Text = clnt.Phone;
            guna2TextBox3_address.Text = clnt.Address;
            guna2TextBox4_adresmail.Text = clnt.EmailAddress;
            clnt.DateofMembership = guna2DateTimePicker1.Value.Date;
            clnt.Type = checkedListBox1_type.SelectedItem.ToString();
            clnt.subscription_number = guna2TextBox6_idmmember.Text;

            flag = false;
            guna2GradientButton1.Text = "Edit New Informations";

        }

        private void deleatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bllclient.Deleat(id);
            DGV();
        }

        private void ClientesForm_Load(object sender, EventArgs e)
        {
            DGV();
        }
    }
}
