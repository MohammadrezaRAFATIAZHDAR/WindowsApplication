﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinnessEntity;
using BussinessLogicLayer;

namespace managing_tecknology_company_application.formes
{
    public partial class Form_employees : Form
    {
        public Form_employees()
        {
            InitializeComponent();
        }
        BLemp bllemp = new BLemp();
        //Specify the progress of the project 
        bool flag=true;
        int id;
        //datagridview
        void DGV()
        {
          guna2DataGridView1.DataSource = null;
          guna2DataGridView1.DataSource = bllemp.Read();
            guna2DataGridView1.Columns["id"].Visible = false;
        }
         
        void Clear()
        {
            
            foreach (var item in Controls)
            {
                if (item.GetType().ToString()== "Guna.UI2.WinForms.Guna2TextBox")
                {
                    (item as TextBox).Text = "";
                }
            }

            
        }
        private void guna2PictureBox1_Click(object sender, EventArgs e)
        {
            Employee emp = new Employee();
            emp.Fullname = guna2TextBox5_fullname.Text;
            emp.EmailAddress = guna2TextBox4_emailaddress.Text;
            emp.Phone = guna2TextBox2_phone.Text;
            emp.Position = guna2ComboBox2_position.SelectedItem.ToString();
            emp.Education = guna2ComboBox2_education.SelectedItem.ToString();
            emp.Address = guna2TextBox3_address.Text;
            emp.PersonelID = guna2TextBox1_personalId.Text;
            emp.Skills = checkedListBox1_skills.SelectedItems.ToString();
            emp.DateofBirth = guna2DateTimePicker1_bod.Value.Date;

            if (flag)
            {
                //create
                MessageBox.Show(bllemp.Create(emp));
            }
            else if (!flag)
            {
                //update
                MessageBox.Show(bllemp.Update(id, emp));
                flag = true;
                guna2GradientButton1.Text = "Save";
            }
             DGV();
             Clear();
        }

        private void guna2DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            id = int.Parse(guna2DataGridView1.Rows[e.RowIndex].Cells["id"].Value.ToString());
        }

        private void guna2DataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.ColumnIndex != -1 && e.RowIndex != -1 && e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                contextMenuStrip1.Show(Cursor.Position.X, Cursor.Position.Y);
            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Employee employee = bllemp.Read(id);
            guna2TextBox5_fullname.Text = employee.Fullname;
            employee.Address = guna2TextBox3_address.Text;
            employee.EmailAddress = guna2TextBox4_emailaddress.Text;
            employee.EmailAddress = guna2ComboBox2_education.SelectedItem.ToString();
            employee.Position = guna2ComboBox2_position.SelectedItem.ToString();
            employee.Phone = guna2TextBox2_phone.Text;
            employee.PersonelID = guna2TextBox1_personalId.Text;
            employee.DateofBirth = guna2DateTimePicker1_bod.Value.Date;
            employee.Skills = checkedListBox1_skills.SelectedItems.ToString();
            flag = false;
            guna2GradientButton1.Text = "Edit New Informations";
        }

        private void deleatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bllemp.Deleat(id);
            DGV();
        }

        private void Form_employees_Load(object sender, EventArgs e)
        {
            DGV();
        }

        private void guna2TextBox7_search_TextChanged(object sender, EventArgs e)
        {
            guna2DataGridView1.DataSource = null;
            guna2DataGridView1.DataSource = bllemp.Read(guna2TextBox7_search.Text);
        }

        private void guna2DataGridView1_CellMouseClick_1(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.ColumnIndex != -1 && e.RowIndex != -1 && e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                contextMenuStrip1.Show(Cursor.Position.X, Cursor.Position.Y);
            }
        }
    }
    
}
