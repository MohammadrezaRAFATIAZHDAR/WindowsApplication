﻿
namespace managing_tecknology_company_application.formes
{
    partial class ContractForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ContractForm));
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.checkedListBox1_type = new System.Windows.Forms.CheckedListBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.guna2GradientButton1_save = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2TextBox7_search = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2DataGridView1 = new Guna.UI2.WinForms.Guna2DataGridView();
            this.label7 = new System.Windows.Forms.Label();
            this.guna2DateTimePicker1_end = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.guna2DateTimePicker1_start = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.guna2TileButton1_upload = new Guna.UI2.WinForms.Guna2TileButton();
            this.label5 = new System.Windows.Forms.Label();
            this.guna2TextBox_PRIce = new Guna.UI2.WinForms.Guna2TextBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.guna2TextBox2_ownerID = new Guna.UI2.WinForms.Guna2TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.guna2TextBox1_prijID = new Guna.UI2.WinForms.Guna2TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.guna2TextBox5_name = new Guna.UI2.WinForms.Guna2TextBox();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.contextMenuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editToolStripMenuItem,
            this.deleatToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(123, 52);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(122, 24);
            this.editToolStripMenuItem.Text = "Edit";
            this.editToolStripMenuItem.Click += new System.EventHandler(this.editToolStripMenuItem_Click);
            // 
            // deleatToolStripMenuItem
            // 
            this.deleatToolStripMenuItem.Name = "deleatToolStripMenuItem";
            this.deleatToolStripMenuItem.Size = new System.Drawing.Size(122, 24);
            this.deleatToolStripMenuItem.Text = "Deleat";
            this.deleatToolStripMenuItem.Click += new System.EventHandler(this.deleatToolStripMenuItem_Click);
            // 
            // checkedListBox1_type
            // 
            this.checkedListBox1_type.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkedListBox1_type.BackColor = System.Drawing.Color.White;
            this.checkedListBox1_type.ForeColor = System.Drawing.Color.Gray;
            this.checkedListBox1_type.FormattingEnabled = true;
            this.checkedListBox1_type.Items.AddRange(new object[] {
            "Web",
            "IOS Applocation",
            "Android Applocation",
            "Windows Application"});
            this.checkedListBox1_type.Location = new System.Drawing.Point(859, 125);
            this.checkedListBox1_type.Name = "checkedListBox1_type";
            this.checkedListBox1_type.Size = new System.Drawing.Size(137, 38);
            this.checkedListBox1_type.TabIndex = 81;
            this.checkedListBox1_type.SelectedIndexChanged += new System.EventHandler(this.checkedListBox1_type_SelectedIndexChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.guna2GradientButton1_save);
            this.panel1.Controls.Add(this.guna2TextBox7_search);
            this.panel1.Controls.Add(this.guna2DataGridView1);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.guna2DateTimePicker1_end);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.guna2DateTimePicker1_start);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.guna2TileButton1_upload);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.guna2TextBox_PRIce);
            this.panel1.Controls.Add(this.checkedListBox1_type);
            this.panel1.Controls.Add(this.numericUpDown1);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.guna2TextBox2_ownerID);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.guna2TextBox1_prijID);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.guna2TextBox5_name);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1038, 720);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // guna2GradientButton1_save
            // 
            this.guna2GradientButton1_save.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2GradientButton1_save.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton1_save.BorderRadius = 20;
            this.guna2GradientButton1_save.CheckedState.Parent = this.guna2GradientButton1_save;
            this.guna2GradientButton1_save.CustomImages.Parent = this.guna2GradientButton1_save;
            this.guna2GradientButton1_save.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton1_save.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton1_save.HoverState.Parent = this.guna2GradientButton1_save;
            this.guna2GradientButton1_save.Location = new System.Drawing.Point(430, 329);
            this.guna2GradientButton1_save.Name = "guna2GradientButton1_save";
            this.guna2GradientButton1_save.ShadowDecoration.Parent = this.guna2GradientButton1_save;
            this.guna2GradientButton1_save.Size = new System.Drawing.Size(180, 45);
            this.guna2GradientButton1_save.TabIndex = 92;
            this.guna2GradientButton1_save.Text = "Save";
            this.guna2GradientButton1_save.Click += new System.EventHandler(this.guna2GradientButton1_save_Click);
            // 
            // guna2TextBox7_search
            // 
            this.guna2TextBox7_search.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2TextBox7_search.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox7_search.DefaultText = "";
            this.guna2TextBox7_search.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox7_search.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox7_search.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox7_search.DisabledState.Parent = this.guna2TextBox7_search;
            this.guna2TextBox7_search.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox7_search.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox7_search.FocusedState.Parent = this.guna2TextBox7_search;
            this.guna2TextBox7_search.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox7_search.HoverState.Parent = this.guna2TextBox7_search;
            this.guna2TextBox7_search.Location = new System.Drawing.Point(65, 667);
            this.guna2TextBox7_search.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox7_search.Name = "guna2TextBox7_search";
            this.guna2TextBox7_search.PasswordChar = '\0';
            this.guna2TextBox7_search.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.guna2TextBox7_search.PlaceholderText = "Search here";
            this.guna2TextBox7_search.SelectedText = "";
            this.guna2TextBox7_search.ShadowDecoration.Parent = this.guna2TextBox7_search;
            this.guna2TextBox7_search.Size = new System.Drawing.Size(935, 40);
            this.guna2TextBox7_search.TabIndex = 91;
            this.guna2TextBox7_search.TextChanged += new System.EventHandler(this.guna2TextBox7_search_TextChanged);
            // 
            // guna2DataGridView1
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.guna2DataGridView1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.guna2DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.guna2DataGridView1.BackgroundColor = System.Drawing.Color.Silver;
            this.guna2DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.guna2DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.guna2DataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.guna2DataGridView1.ColumnHeadersHeight = 4;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.guna2DataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.guna2DataGridView1.EnableHeadersVisualStyles = false;
            this.guna2DataGridView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.Location = new System.Drawing.Point(65, 392);
            this.guna2DataGridView1.Name = "guna2DataGridView1";
            this.guna2DataGridView1.RowHeadersVisible = false;
            this.guna2DataGridView1.RowHeadersWidth = 51;
            this.guna2DataGridView1.RowTemplate.Height = 24;
            this.guna2DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.guna2DataGridView1.Size = new System.Drawing.Size(935, 267);
            this.guna2DataGridView1.TabIndex = 90;
            this.guna2DataGridView1.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Default;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView1.ThemeStyle.BackColor = System.Drawing.Color.Silver;
            this.guna2DataGridView1.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.Height = 4;
            this.guna2DataGridView1.ThemeStyle.ReadOnly = false;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.guna2DataGridView1.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.Height = 24;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.guna2DataGridView1_CellClick);
            this.guna2DataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.guna2DataGridView1_CellContentClick);
            this.guna2DataGridView1.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.guna2DataGridView1_CellMouseClick);
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Gray;
            this.label7.Location = new System.Drawing.Point(720, 250);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(94, 15);
            this.label7.TabIndex = 89;
            this.label7.Text = "Delivery date:";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // guna2DateTimePicker1_end
            // 
            this.guna2DateTimePicker1_end.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2DateTimePicker1_end.BackColor = System.Drawing.Color.Transparent;
            this.guna2DateTimePicker1_end.BorderRadius = 10;
            this.guna2DateTimePicker1_end.CheckedState.Parent = this.guna2DateTimePicker1_end;
            this.guna2DateTimePicker1_end.FillColor = System.Drawing.Color.Gray;
            this.guna2DateTimePicker1_end.FocusedColor = System.Drawing.Color.DarkGray;
            this.guna2DateTimePicker1_end.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2DateTimePicker1_end.ForeColor = System.Drawing.Color.White;
            this.guna2DateTimePicker1_end.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.guna2DateTimePicker1_end.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.guna2DateTimePicker1_end.HoverState.Parent = this.guna2DateTimePicker1_end;
            this.guna2DateTimePicker1_end.Location = new System.Drawing.Point(859, 218);
            this.guna2DateTimePicker1_end.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.guna2DateTimePicker1_end.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.guna2DateTimePicker1_end.Name = "guna2DateTimePicker1_end";
            this.guna2DateTimePicker1_end.ShadowDecoration.Parent = this.guna2DateTimePicker1_end;
            this.guna2DateTimePicker1_end.Size = new System.Drawing.Size(137, 85);
            this.guna2DateTimePicker1_end.TabIndex = 88;
            this.guna2DateTimePicker1_end.Value = new System.DateTime(2022, 3, 9, 14, 49, 45, 685);
            this.guna2DateTimePicker1_end.ValueChanged += new System.EventHandler(this.guna2DateTimePicker1_end_ValueChanged);
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Gray;
            this.label9.Location = new System.Drawing.Point(344, 250);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 15);
            this.label9.TabIndex = 87;
            this.label9.Text = "Start Date:";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // guna2DateTimePicker1_start
            // 
            this.guna2DateTimePicker1_start.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2DateTimePicker1_start.BackColor = System.Drawing.Color.Transparent;
            this.guna2DateTimePicker1_start.BorderRadius = 10;
            this.guna2DateTimePicker1_start.CheckedState.Parent = this.guna2DateTimePicker1_start;
            this.guna2DateTimePicker1_start.FillColor = System.Drawing.Color.Gray;
            this.guna2DateTimePicker1_start.FocusedColor = System.Drawing.Color.DarkGray;
            this.guna2DateTimePicker1_start.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2DateTimePicker1_start.ForeColor = System.Drawing.Color.White;
            this.guna2DateTimePicker1_start.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.guna2DateTimePicker1_start.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.guna2DateTimePicker1_start.HoverState.Parent = this.guna2DateTimePicker1_start;
            this.guna2DateTimePicker1_start.Location = new System.Drawing.Point(464, 218);
            this.guna2DateTimePicker1_start.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.guna2DateTimePicker1_start.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.guna2DateTimePicker1_start.Name = "guna2DateTimePicker1_start";
            this.guna2DateTimePicker1_start.ShadowDecoration.Parent = this.guna2DateTimePicker1_start;
            this.guna2DateTimePicker1_start.Size = new System.Drawing.Size(152, 85);
            this.guna2DateTimePicker1_start.TabIndex = 86;
            this.guna2DateTimePicker1_start.Value = new System.DateTime(2022, 3, 9, 14, 49, 45, 685);
            this.guna2DateTimePicker1_start.ValueChanged += new System.EventHandler(this.guna2DateTimePicker1_start_ValueChanged);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Location = new System.Drawing.Point(152, 218);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(137, 85);
            this.pictureBox2.TabIndex = 85;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            this.pictureBox2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBox2_MouseClick);
            // 
            // guna2TileButton1_upload
            // 
            this.guna2TileButton1_upload.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2TileButton1_upload.CheckedState.Parent = this.guna2TileButton1_upload;
            this.guna2TileButton1_upload.CustomImages.Parent = this.guna2TileButton1_upload;
            this.guna2TileButton1_upload.FillColor = System.Drawing.Color.White;
            this.guna2TileButton1_upload.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TileButton1_upload.ForeColor = System.Drawing.Color.White;
            this.guna2TileButton1_upload.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(102)))), ((int)(((byte)(244)))));
            this.guna2TileButton1_upload.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.guna2TileButton1_upload.HoverState.Image = ((System.Drawing.Image)(resources.GetObject("guna2TileButton1_upload.HoverState.Image")));
            this.guna2TileButton1_upload.HoverState.Parent = this.guna2TileButton1_upload;
            this.guna2TileButton1_upload.Image = ((System.Drawing.Image)(resources.GetObject("guna2TileButton1_upload.Image")));
            this.guna2TileButton1_upload.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2TileButton1_upload.Location = new System.Drawing.Point(75, 218);
            this.guna2TileButton1_upload.Name = "guna2TileButton1_upload";
            this.guna2TileButton1_upload.ShadowDecoration.Parent = this.guna2TileButton1_upload;
            this.guna2TileButton1_upload.Size = new System.Drawing.Size(51, 60);
            this.guna2TileButton1_upload.TabIndex = 84;
            this.guna2TileButton1_upload.Click += new System.EventHandler(this.guna2TileButton1_upload_Click);
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gray;
            this.label5.Location = new System.Drawing.Point(375, 137);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 15);
            this.label5.TabIndex = 83;
            this.label5.Text = "Price:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // guna2TextBox_PRIce
            // 
            this.guna2TextBox_PRIce.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2TextBox_PRIce.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox_PRIce.DefaultText = "";
            this.guna2TextBox_PRIce.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox_PRIce.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox_PRIce.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox_PRIce.DisabledState.Parent = this.guna2TextBox_PRIce;
            this.guna2TextBox_PRIce.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox_PRIce.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox_PRIce.FocusedState.Parent = this.guna2TextBox_PRIce;
            this.guna2TextBox_PRIce.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox_PRIce.HoverState.Parent = this.guna2TextBox_PRIce;
            this.guna2TextBox_PRIce.Location = new System.Drawing.Point(467, 122);
            this.guna2TextBox_PRIce.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox_PRIce.Name = "guna2TextBox_PRIce";
            this.guna2TextBox_PRIce.PasswordChar = '\0';
            this.guna2TextBox_PRIce.PlaceholderText = "Enter the price";
            this.guna2TextBox_PRIce.SelectedText = "";
            this.guna2TextBox_PRIce.ShadowDecoration.Parent = this.guna2TextBox_PRIce;
            this.guna2TextBox_PRIce.Size = new System.Drawing.Size(149, 30);
            this.guna2TextBox_PRIce.TabIndex = 82;
            this.guna2TextBox_PRIce.TextChanged += new System.EventHandler(this.guna2TextBox_PRIce_TextChanged);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.numericUpDown1.ForeColor = System.Drawing.Color.Gray;
            this.numericUpDown1.Location = new System.Drawing.Point(863, 55);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(137, 22);
            this.numericUpDown1.TabIndex = 80;
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gray;
            this.label6.Location = new System.Drawing.Point(766, 140);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 15);
            this.label6.TabIndex = 78;
            this.label6.Text = "Type:";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gray;
            this.label4.Location = new System.Drawing.Point(75, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 15);
            this.label4.TabIndex = 76;
            this.label4.Text = "ID:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gray;
            this.label3.Location = new System.Drawing.Point(766, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 15);
            this.label3.TabIndex = 75;
            this.label3.Text = "Grade:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // guna2TextBox2_ownerID
            // 
            this.guna2TextBox2_ownerID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2TextBox2_ownerID.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox2_ownerID.DefaultText = "";
            this.guna2TextBox2_ownerID.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox2_ownerID.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox2_ownerID.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox2_ownerID.DisabledState.Parent = this.guna2TextBox2_ownerID;
            this.guna2TextBox2_ownerID.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox2_ownerID.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox2_ownerID.FocusedState.Parent = this.guna2TextBox2_ownerID;
            this.guna2TextBox2_ownerID.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox2_ownerID.HoverState.Parent = this.guna2TextBox2_ownerID;
            this.guna2TextBox2_ownerID.Location = new System.Drawing.Point(464, 49);
            this.guna2TextBox2_ownerID.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox2_ownerID.Name = "guna2TextBox2_ownerID";
            this.guna2TextBox2_ownerID.PasswordChar = '\0';
            this.guna2TextBox2_ownerID.PlaceholderText = "Owner\'s ID:";
            this.guna2TextBox2_ownerID.SelectedText = "";
            this.guna2TextBox2_ownerID.ShadowDecoration.Parent = this.guna2TextBox2_ownerID;
            this.guna2TextBox2_ownerID.Size = new System.Drawing.Size(152, 28);
            this.guna2TextBox2_ownerID.TabIndex = 69;
            this.guna2TextBox2_ownerID.TextChanged += new System.EventHandler(this.guna2TextBox2_ownerID_TextChanged);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gray;
            this.label2.Location = new System.Drawing.Point(367, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 15);
            this.label2.TabIndex = 74;
            this.label2.Text = "Owner:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // guna2TextBox1_prijID
            // 
            this.guna2TextBox1_prijID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2TextBox1_prijID.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox1_prijID.DefaultText = "";
            this.guna2TextBox1_prijID.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox1_prijID.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox1_prijID.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox1_prijID.DisabledState.Parent = this.guna2TextBox1_prijID;
            this.guna2TextBox1_prijID.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox1_prijID.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox1_prijID.FocusedState.Parent = this.guna2TextBox1_prijID;
            this.guna2TextBox1_prijID.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox1_prijID.HoverState.Parent = this.guna2TextBox1_prijID;
            this.guna2TextBox1_prijID.Location = new System.Drawing.Point(152, 125);
            this.guna2TextBox1_prijID.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox1_prijID.Name = "guna2TextBox1_prijID";
            this.guna2TextBox1_prijID.PasswordChar = '\0';
            this.guna2TextBox1_prijID.PlaceholderText = "Enter the project ID";
            this.guna2TextBox1_prijID.SelectedText = "";
            this.guna2TextBox1_prijID.ShadowDecoration.Parent = this.guna2TextBox1_prijID;
            this.guna2TextBox1_prijID.Size = new System.Drawing.Size(137, 30);
            this.guna2TextBox1_prijID.TabIndex = 68;
            this.guna2TextBox1_prijID.TextChanged += new System.EventHandler(this.guna2TextBox1_prijID_TextChanged);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gray;
            this.label1.Location = new System.Drawing.Point(62, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 15);
            this.label1.TabIndex = 73;
            this.label1.Text = "Name:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // guna2TextBox5_name
            // 
            this.guna2TextBox5_name.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2TextBox5_name.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox5_name.DefaultText = "";
            this.guna2TextBox5_name.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox5_name.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox5_name.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox5_name.DisabledState.Parent = this.guna2TextBox5_name;
            this.guna2TextBox5_name.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox5_name.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox5_name.FocusedState.Parent = this.guna2TextBox5_name;
            this.guna2TextBox5_name.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox5_name.HoverState.Parent = this.guna2TextBox5_name;
            this.guna2TextBox5_name.Location = new System.Drawing.Point(152, 49);
            this.guna2TextBox5_name.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox5_name.Name = "guna2TextBox5_name";
            this.guna2TextBox5_name.PasswordChar = '\0';
            this.guna2TextBox5_name.PlaceholderText = "Enter Project Nmae";
            this.guna2TextBox5_name.SelectedText = "";
            this.guna2TextBox5_name.ShadowDecoration.Parent = this.guna2TextBox5_name;
            this.guna2TextBox5_name.Size = new System.Drawing.Size(137, 30);
            this.guna2TextBox5_name.TabIndex = 72;
            this.guna2TextBox5_name.TextChanged += new System.EventHandler(this.guna2TextBox5_name_TextChanged);
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.printToolStripMenuItem});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(109, 28);
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new System.Drawing.Size(108, 24);
            this.printToolStripMenuItem.Text = "Print";
            this.printToolStripMenuItem.Click += new System.EventHandler(this.printToolStripMenuItem_Click);
            // 
            // ContractForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1038, 720);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ContractForm";
            this.Text = "ContractForm";
            this.Load += new System.EventHandler(this.ContractForm_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.contextMenuStrip2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleatToolStripMenuItem;
        private System.Windows.Forms.CheckedListBox checkedListBox1_type;
        private System.Windows.Forms.Panel panel1;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1_save;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox7_search;
        private Guna.UI2.WinForms.Guna2DataGridView guna2DataGridView1;
        private System.Windows.Forms.Label label7;
        private Guna.UI2.WinForms.Guna2DateTimePicker guna2DateTimePicker1_end;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2DateTimePicker guna2DateTimePicker1_start;
        private System.Windows.Forms.PictureBox pictureBox2;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton1_upload;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox_PRIce;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox2_ownerID;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox1_prijID;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox5_name;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
    }
}