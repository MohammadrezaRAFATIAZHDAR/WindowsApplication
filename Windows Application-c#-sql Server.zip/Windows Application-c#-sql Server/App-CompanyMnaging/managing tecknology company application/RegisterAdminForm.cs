﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinnessEntity;
using BussinessLogicLayer;
using FoxLearn.License;

namespace managing_tecknology_company_application
{
    public partial class RegisterAdminForm : Form
    {
        public RegisterAdminForm()
        {
            InitializeComponent();
           
        }

        BLLlogin blllogin = new BLLlogin();


        //drag form
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);

        void Move()
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }
        private void guna2GradientTileButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void guna2TileButton2_Click(object sender, EventArgs e)
        {
            if (guna2TextBox6.Text == guna2TextBox5.Text)
            {
                blllogin.Register(new login() { Name = guna2TextBox4.Text, username = guna2TextBox3.Text, password = guna2TextBox5.Text });
                MessageBox.Show("A new admin created ");
                this.Close();

            }

        }

        private void RegisterAdminForm_Load(object sender, EventArgs e)
        {
            guna2TextBox1.Text = ComputerInfo.GetComputerId();
        }

        private void guna2TileButton1_Click(object sender, EventArgs e)
        {
            KeyManager km = new KeyManager(guna2TextBox1.Text);
            string productKey = guna2TextBox2.Text;
            if (km.ValidKey(ref productKey))
            {
                KeyValuesClass kv = new KeyValuesClass();
                if (km.DisassembleKey(productKey, ref kv))
                {
                    LicenseInfo lic = new LicenseInfo();
                    lic.ProductKey = productKey;
                    lic.FullName = "Personal accounting";
                    if (kv.Type == LicenseType.TRIAL)
                    {
                        lic.Day = kv.Expiration.Day;
                        lic.Month = kv.Expiration.Month;
                        lic.Year = kv.Expiration.Year;
                    }
                    km.SaveSuretyFile(string.Format(@"{0}\Key.lic", Application.StartupPath), lic);
                    MessageBox.Show("Application activation completed successfully!", "Done!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    groupBox2.Enabled = true;
                }
            }
            else
            {
                MessageBox.Show("Invalid license!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                guna2TextBox2.Focus();
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void RegisterAdminForm_MouseDown(object sender, MouseEventArgs e)
        {
            Move();
        }
    }
}
