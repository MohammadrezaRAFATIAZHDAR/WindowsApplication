﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinnessEntity
{
     public class Clientes
    {
        public int id { get; set; }
        public string  Name { get; set; }
        public string Phone { get; set; }
        public string EmailAddress { get; set; }
        public string Address { get; set; }
        public string Type { get; set; }
        public DateTime DateofMembership { get; set; }
        public string subscription_number { get; set; }

        public List<contract> Contracts { set; get; } = new List<contract>();
    }
}
