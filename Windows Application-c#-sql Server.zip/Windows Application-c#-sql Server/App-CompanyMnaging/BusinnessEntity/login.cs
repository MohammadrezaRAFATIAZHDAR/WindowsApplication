﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinnessEntity
{
    public class login
    {
        public int id { get; set; }
        public string Name { get; set; }
        public string username { get; set; }
        public string password { get; set; }
    }
}
