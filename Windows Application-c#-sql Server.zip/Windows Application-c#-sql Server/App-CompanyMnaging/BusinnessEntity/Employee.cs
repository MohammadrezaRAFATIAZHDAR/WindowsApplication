﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinnessEntity
{
    public class Employee
    {
        public int id { get; set; }
        public string Fullname { get; set; }
        public string Phone { get; set; }
        public string EmailAddress { get; set; }
        public string Address { get; set; }
        public string Position { get; set; }
        public string Education { get; set; }
        public string Skills { get; set; }
        public DateTime DateofBirth { get; set; }
        public string PersonelID { get; set; }
    }
}
