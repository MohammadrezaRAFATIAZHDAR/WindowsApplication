﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinnessEntity;
using DataAccessLayer;

namespace BussinessLogicLayer
{
    public class BLLContract
    {
        dalContracts dalContracts = new dalContracts();

        public string Create(contract ctr)
        {
            return dalContracts.Create(ctr);
        }

        public List<contract> Read(string name)
        {
            return dalContracts.Read(name);
        }
        public contract Read(int id)
        {
            return dalContracts.Read(id);
        }

        public List<contract> Read()
        {
            return dalContracts.show();
        }
        public int GetRecord()
        {
            return dalContracts.GetRecorde();
        }
        public string Update(int id, contract ctrtNew)
        {
            return dalContracts.Update(id, ctrtNew);
        }

        public string Deleat(int id)
        {
            return dalContracts.Deleat(id);
        }
    }
}
