﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinnessEntity;
using DataAccessLayer;

namespace BussinessLogicLayer
{
    public class BLLclientes
    {
        dalClientes dalClientes = new dalClientes();
        public string Create(Clientes clnt)
        {
            return dalClientes.Create(clnt);
        }

        public List<Clientes> Read(string name)
        {
            return dalClientes.Read(name);
        }

        public Clientes Read(int id)
        {
            return dalClientes.Read(id);
        }

        public List<Clientes> Read()
        {
            return dalClientes.Read();
        }
        public int GetRecord()
        {
            return dalClientes.GetRecord();
        }
        public string Update(int id,Clientes clntNew)
        {
            return dalClientes.Update(id, clntNew);
        }

        public string Deleat(int id)
        {
            return dalClientes.Deleat(id);
        }
    }
}

